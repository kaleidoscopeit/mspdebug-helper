Install :

sudo apt-get install hal
