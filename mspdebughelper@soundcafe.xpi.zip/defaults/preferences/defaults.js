// device
pref("extensions.mspdebughelper.programmer.driver",
     "chrome://mspdebughelper/locale/preferences.properties");
pref("extensions.mspdebughelper.programmer.link",
     "chrome://mspdebughelper/locale/preferences.properties");
pref("extensions.mspdebughelper.programmer.voltage",
     "chrome://mspdebughelper/locale/preferences.properties");

// commands
pref("extensions.mspdebughelper.programmer.paths_workdir",
     "chrome://mspdebughelper/locale/preferences.properties");
pref("extensions.mspdebughelper.programmer.paths_mspdebug",
     "chrome://mspdebughelper/locale/preferences.properties");
pref("extensions.mspdebughelper.programmer.paths_libmsp430",
     "chrome://mspdebughelper/locale/preferences.properties");
pref("extensions.mspdebughelper.programmer.paths_msp430gdb",
     "chrome://mspdebughelper/locale/preferences.properties");
pref("extensions.mspdebughelper.programmer.paths_pport",
     "chrome://mspdebughelper/locale/preferences.properties");